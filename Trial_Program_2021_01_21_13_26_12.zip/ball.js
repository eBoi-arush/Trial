  class ball {
  
  constructor(){
    
    this.xPosition=0;
    this.yPosition=0;
    this.height=0;
    this.length=0;
  
  }
  
  display(){
    rect(this.xPosition, this.yPosition, this.length, this.height);
  }
}