var sub_1, sub_2, sub_3, sub_4;

function setup() {
  createCanvas(400, 400);
  fill("gray")
  
  sub_1=new ball();
  sub_1.length=5;
  sub_1.height=10;
  sub_1.yPosition=1;
  
  sub_2=new ball();
  sub_2.length=10;
  sub_2.height=5
  sub_2.xPosition=1;
  sub_2.yPosition=mouseY;
  
  //This part is ommiited
  /*
  sub_3=new ball();
  sub_3.xPosition=10;
  sub_3.yPosition=340;
  
  sub_4=new ball();
  sub_4.xPosition=340;
  sub_4.yPosition=10;
  */
}

function draw() {
    background("cyan");
  sub_1.display();
  sub_2.display();
  
  sub_1.xPosition=mouseX;
  sub_2.yPosition=mouseY;
}